/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
   float bmi,weight,height;
   printf("Enter weight: ");
   scanf("%f",&weight);
   printf("Enter height: ");
   scanf("%f",&height);
   
    bmi = weight/(pow(height, 2));
    
    if(bmi<=15)
    {
        printf("STARVATION: ");
    }
    else if(bmi>=15.1 && bmi<=17.5)
    {
        printf("ANOREXIC:");
    }
    else if(bmi>=17.6 && bmi<=18.5)
    {
         printf("UNDERWEIGHT:");
    }
    else if(bmi>=18.6 && bmi<=24.9)
    {
        printf("IDEAL:");
    }
    else if(bmi>=25 && bmi<=25.9)
    {
        printf("OVERWEIGHT:");
    }
    else if(bmi>=30 && bmi<=30.9)
    {
        printf("OBESE:");
    }
    else
    printf("MORBIDLY OBESE: ");
}