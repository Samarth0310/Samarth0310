/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    float b,c,d;
    printf("enter ramesh basic salary: ");
    scanf("%d",&a);
    b=a*0.4;
    c=a*0.2;
    d=a-b-c;
    printf("ramesh's gross salary is %0.2f",d);

    return 0;
}

