/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char a;
    printf("enter a character: ");
    scanf("%c",&a);
    
    if(a>=65 && a<=99)
    {
        printf("It is a capital letter: ");
    }
    else if(a>=48 && a<=57)
    {
        printf("It is a number: ");
    }
    else if(a>=97 && a<=122)
    {
        printf("It is a small letter: ");
    }
    else
    printf("It is a special symbol: ");
}
