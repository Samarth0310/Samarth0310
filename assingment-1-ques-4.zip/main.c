/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float ft,ct;
    printf("enter temperature in fahrenheit: ");
    scanf("%f",&ft);
    ct=(5.0/9.0)*(ft-32.0);
    printf("temperature in centigrade is %0.2f",ct);

    return 0;
}

