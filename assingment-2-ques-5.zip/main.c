/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int r,s,a;
    printf("Enter the age of ram\n");
    scanf("%d",&r);
    printf("Enter the age of shyam\n");
    scanf("%d",&s);
    printf("Enter the age of ajay\n");
    scanf("%d",&a);
    
    if(r<s && r<a)
    {
     printf("Ram is youngest of them %d",r);
    }
    
    else if (s<r && s<a)
    {
        printf("Shyam is youngest of them %d",s);
    }
    
    else
    printf("Aman is youngest of them %d",a);
    
}
