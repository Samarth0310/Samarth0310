/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float w;
    printf("Enter the weight: ");
    scanf("%f",&w);
    
    if(w<115)
    {
        printf("Weight class is FLYWEIGHT: ");
    }
    else if(w>=115 && w<=121)
    {
         printf("Weight class is BANTAMWEIGHT: ");
    }
    else if(w>=122 && w<=153)
    {
        printf("Weight class is FEATHERWEIGHT: ");
    }
    else if(w>=154 && w<=189)
    {
        printf("Weight class is MIDDLEWEIGHT: ");
    }
    else
    printf("Weight class is HEAVYWEIGHT: ");
}
    