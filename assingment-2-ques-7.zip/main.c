/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int l,b,a,p;
    printf("enter length of rectangle \n");
    scanf("%d",&l);
    printf("enter breadth of rectangle \n");
    scanf("%d",&b);
    a=(l*b);
    p=2*(l+b);
    
    if (a>p)
    {
        printf("area of rectangle is greater than perimeter %d",a);
    }
    
    else
    {
        printf("area of rectangle is not greater than perimeter  %d",p);
    }
    
}
