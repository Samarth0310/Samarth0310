/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int y;
    printf("enter the year \n");
    scanf("%d",&y);
    
    if (y%4==0)
    {
        printf("it is a leap year %d",y);
    }
    
    else
    {
        printf("it is not a leap year %d",y);
    }
}
