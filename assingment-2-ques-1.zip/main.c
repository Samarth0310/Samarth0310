/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int c,s,tl,tp;
    printf("Enter the Cost price\n");
    scanf("%d",&c);
    printf("Enter the Selling price\n");
    scanf("%d",&s);

    if(s>c)
    {
       tp=s-c;
       printf("The profit is %d",tp);
    }
    else if (s<c)
    {
        tl=c-s;
       printf("The loss is %d",tl);
    }
    else
    printf("There is neither profit nor loss");
}
