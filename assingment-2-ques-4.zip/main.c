/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b,c,s;
    printf("angle 1 \n");
    scanf("%d",&a);
    printf("angle 2 \n");
    scanf("%d",&b);
    printf("angle 3 \n");
    scanf("%d",&c);
    s=a+b+c;
    
    if(s==180)
    {
        printf("triangle is valid %d",s);
    }
    
    else
    {
        printf("triangle is not valid  %d",s);
    }
}
