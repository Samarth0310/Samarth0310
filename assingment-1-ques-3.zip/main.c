/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int m1,e2,p3,ch4,c5,agg;
    float per;
    printf("input marks of student obtained in 5 subject:\n");
    scanf("%d,%d,%d,%d,%d,%d",&m1,&e2,&p3,&ch4,&c5);
    agg=m1+e2+p3+ch4+c5;
    per=(agg/5.0);
    printf("aggregate marks obtained by student= %d\n",agg);
    printf("percentage of student= %0.2f ",per);
    
    return 0;
}



